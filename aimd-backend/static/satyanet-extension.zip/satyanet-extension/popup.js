document.getElementById('uploadBtn').addEventListener('click', async () => {
    const fileInput = document.getElementById('mediaFile');
    const resultDiv = document.getElementById('result');

    if (!fileInput.files[0]) {
        alert("Select A File First !!");
        return;
    }

    const formData = new FormData();
    formData.append('file', fileInput.files[0]);

    document.getElementById('uploadBtn').innerText = "Analyzing...";

    try {
        const res = await fetch('https://satyanet.onrender.com/evidence/upload', {
            method: 'POST',
            body: formData
        });

        const data = await res.json();

        document.getElementById('verdict').innerText = data.verdict;
        document.getElementById('score').innerText = (data.ai_probability_score * 100).toFixed(1) + "% AI";
        document.getElementById('cid').innerText = data.forensic_details.ipfs_cid || "Pinned";
        resultDiv.style.display = "block";
    } catch (err) {
        alert("Error uploading file to SatyaNET backend");
    } finally {
        document.getElementById('uploadBtn').innerText = "Analyze Evidence";
    }
});